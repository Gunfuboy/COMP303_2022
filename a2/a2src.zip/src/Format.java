public enum Format {
    MP4, MOV, WMV, AVI, FLV, MKV
}
