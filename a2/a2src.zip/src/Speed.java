public enum Speed {
    LOW, MODERATE, HIGH
}
