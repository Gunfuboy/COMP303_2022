public enum Tricks {
    TakeOff, Pucker, Land
}
